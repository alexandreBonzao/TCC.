import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import Container from "react-bootstrap/Container";
import styles from "./Menu.module.css";

export default function Menu() {
  return (
    <div className={styles.principal}>
      <Navbar expand="lg" className={styles.navbar}>
        <Container fluid className={styles.conteiner} style={{ color: "white" }}>

          {/* Botão no canto direito */}
          <Navbar.Toggle
            aria-controls="menu-responsivo"
            style={{ marginLeft: "auto" }}
          />

          <Navbar.Collapse id="menu-responsivo" className={styles.colapso}>
            <div className={styles.centralizador}>
              <Nav className={styles.menu}>

              <NavDropdown
                title={<span style={{ color: "white", marginLeft: "20px", textShadow:'none' }}>Categorias</span>}
                className={styles.itens}>
                  
                <div className={styles.itensdrop}>
                  <NavDropdown.Item href="#action/3.1" style={{ color: "white", textShadow:'none' }}>Serviços</NavDropdown.Item>
                  <NavDropdown.Item href="#action/3.2" style={{ color: "white", textShadow:'none' }}>Maquinário</NavDropdown.Item>
                  <NavDropdown.Item href="#action/3.3" style={{ color: "white", textShadow:'none' }}>Peças</NavDropdown.Item>
                  <NavDropdown.Item href="#action/3.3" style={{ color: "white", textShadow:'none' }}>Produtos</NavDropdown.Item>
                  
                </div>
              </NavDropdown>

              <Nav.Link
                className={styles.itens}
                style={{ color: "white", marginLeft: "20px" }}
                href="#vender"
              >
                Vender
              </Nav.Link>
              <Nav.Link
                className={styles.itens}
                style={{ color: "white", marginLeft: "20px" }}
                href="#contato"
              >
                Contato
              </Nav.Link>
              <Nav.Link
                className={styles.itens}
                style={{ color: "white", marginLeft: "20px" }}
                href="#conta"
              >
                Conta
              </Nav.Link>
            </Nav>
            </div>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
}
