import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import styles from "./Menu.module.css";

export default function Topo() {
  return (
    <div>
      <Navbar expand="lg" className={styles.navbar}>
        <Container style={{ color: "white" }} className={styles.conteiner}>
          <Nav className={styles.titulo}>
            <NavDropdown
              title={
                <span
                  style={{
                    color: "white",
                    textShadow: "none",
                    marginLeft: "20px",
                  }}
                >
                  Categorias
                </span>
              }
            >
              <NavDropdown.Item href="#action/3.1">Serviços</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2"> Maquinário / Peças</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Produtos</NavDropdown.Item>
            </NavDropdown>

            <Nav.Link
              style={{ color: "white", textShadow: "none", marginLeft: "20px" }}
              href="#home"
            >
              Vender
            </Nav.Link>
            <Nav.Link
              style={{ color: "white", textShadow: "none", marginLeft: "20px" }}
              href="#link"
            >
              Contato
            </Nav.Link>
            <Nav.Link
              style={{ color: "white", textShadow: "none", marginLeft: "20px" }}
              href="#link"
            >
              Conta
            </Nav.Link>
          </Nav>
        </Container>
      </Navbar>
    </div>
  );
}
