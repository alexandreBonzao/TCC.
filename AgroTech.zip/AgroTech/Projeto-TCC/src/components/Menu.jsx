import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import styles from './Menu.module.css';

export default function Topo() {
    return (

      <Navbar expand="lg" className={styles.navbar}>
      <Container>
          <Nav className={styles.titulo}>
            <NavDropdown className={styles.drop} title="Categorias">
              <NavDropdown.Item href="#action/3.1">Serviços</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">Maquinário</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
            </NavDropdown>

            <Nav.Link href="#home">Produtos</Nav.Link>
            <Nav.Link href="#home">Vender</Nav.Link>
            <Nav.Link href="#link">Contato</Nav.Link>
          </Nav>

      </Container>
    </Navbar>

    );
  }