import styles from './Menu.module.css';

export default function Topo() {
    return (
      <div className={styles.menu}>
        <ul>
          <li><h1>Categorias</h1></li>
          <li><h1>Ofertas</h1></li>
          <li><h1>Vender</h1></li>
          <li><h1>Contato</h1></li>
        </ul>
      </div>
    );
  }