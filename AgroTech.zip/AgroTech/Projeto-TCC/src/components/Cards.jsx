import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import styles from "./Cards.module.css"; 
import servicos from "../assets/servicos.png"

function Cards() {
  return (
    <div className={styles.tudo}>

      <div className={styles.sla}>
      <Card className={styles.cubao}>
        <Card.Title className={styles.titulo}>Serviços</Card.Title>
          <Card.Body>
            <Card.Img className={styles.imgservico} src={servicos}/>
            <Card.Text className={styles.descricao}>Compra e venda de serviços</Card.Text>
            <Button className={styles.botao}>Buscar</Button>
          </Card.Body>
      </Card>
    </div>  
      <Card className={styles.cubao}>
        <Card.Title className={styles.titulo}>Maquinários</Card.Title>
          <Card.Body>
            <Card.Img className={styles.imgservico} src={servicos}/>
            <Card.Text className={styles.descricao}>Compra e venda de serviços</Card.Text>
            <Button className={styles.botao}>Buscar</Button>
          </Card.Body>
      </Card>

      <Card className={styles.cubao}>
        <Card.Title className={styles.titulo}>Peças</Card.Title>
          <Card.Body>
            <Card.Img className={styles.imgservico} src={servicos}/>
            <Card.Text className={styles.descricao}>Compra e venda de serviços</Card.Text>
            <Button className={styles.botao}>Buscar</Button>
          </Card.Body>
      </Card>

      <Card className={styles.cubao}>
        <Card.Title className={styles.titulo}>Produtos</Card.Title>
          <Card.Body>
            <Card.Img className={styles.imgservico} src={servicos}/>
            <Card.Text className={styles.descricao}>Compra e venda de serviços</Card.Text>
            <Button className={styles.botao}>Buscar</Button>
          </Card.Body>
      </Card>
    </div>
  );
}

export default Cards;