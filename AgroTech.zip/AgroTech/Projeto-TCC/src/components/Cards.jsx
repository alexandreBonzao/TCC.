import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import styles from "./Coisa.module.css";

function Cards() {
  return (
    <div style={{ display: 'flex', backgroundColor: '#2D6A4F', height: '20vw'}}>
      <Card style={{ width: '18rem', marginLeft: '8%',marginTop: '2vw', marginBottom: '2vw', borderRadius: '15px'}}>
        <Card.Img variant="top" src="holder.js/100px180" />
        <Card.Body>
          <Card.Title>Card Title</Card.Title>
          <Card.Text>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </Card.Text>
          <Button style={{ marginTop:'5,5vw', marginLeft:'3vw' }}>Go somewhere</Button>
        </Card.Body>
      </Card>

      <Card style={{ width: '18rem', marginLeft: '8%', marginTop: '2vw', marginBottom: '2vw', borderRadius: '15px'}}>
        <Card.Img variant="top" src="holder.js/100px180" />
        <Card.Body>
          <Card.Title>Card Title</Card.Title>
          <Card.Text>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </Card.Text>
          <Button style={{ marginTop:'5,5vw', marginLeft:'3vw' }}>Go somewhere</Button>
        </Card.Body>
      </Card>

      <Card style={{ width: '18rem', marginLeft: '8%', marginTop: '2vw', marginBottom: '2vw', borderRadius: '15px'}}>
        <Card.Img variant="top" src="holder.js/100px180" />
        <Card.Body>
          <Card.Title>Card Title</Card.Title>
          <Card.Text>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </Card.Text>
          <Button style={{ marginTop:'5,5vw', marginLeft:'3vw' }}>Go somewhere</Button>
        </Card.Body>
      </Card>

      <Card style={{ width: '18rem', marginLeft: '8%', marginTop: '2vw', marginBottom: '2vw', borderRadius: '15px'}}>
        <Card.Img variant="top" src="holder.js/100px180" /> 
        <Card.Body>
          <Card.Title>Card Title</Card.Title>
          <Card.Text>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </Card.Text>
          <Button style={{ marginTop:'5,5vw', marginLeft:'3vw' }}>Go somewhere</Button>
        </Card.Body>
      </Card>
    </div>
  );
}

export default Cards;