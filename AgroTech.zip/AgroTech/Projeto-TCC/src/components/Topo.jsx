import styles from './Topo.module.css';
import logo from '../assets/logo.png';
import lupa from '../assets/procurar.png';

export default function Topo() {
  return (
    <div className={styles.topo}>
      <div>
        <img src={logo} alt="Logo do site" className={styles.logo} />
      </div>

      <div className={styles.pesquisa}>
        <input type="text" placeholder="Buscar" />
        <img src={lupa} alt="Ícone de busca" className={styles.iconeBusca} />
      </div>

      <div className={styles.perfil}>
        {/* Pode colocar uma foto, botão de login, etc */}
      </div>
    </div>
  );
}