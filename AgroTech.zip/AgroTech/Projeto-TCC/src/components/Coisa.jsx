import styles from './Coisa.module.css';

export default function Topo() {
    return (
        <div className={styles.coisa}></div>
    );
  }