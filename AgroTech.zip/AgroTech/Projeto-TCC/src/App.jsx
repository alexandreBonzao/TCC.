import Topo from './components/Topo.jsx'
import './App.css'

function App() {


  return (
    <div className="App">
    <Topo/>
  </div>
  )
}

export default App
