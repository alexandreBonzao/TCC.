import Topo from './components/Topo.jsx'
import Menu from './components/Menu.jsx'
import Coisa from './components/Coisa.jsx'
import Cards from './components/Cards.jsx'
import './App.css'
import { Card } from 'react-bootstrap'



function App() {


  return (
    <div className="App">
    <Topo/>
    <Menu/>
    <Coisa/>  
    <Cards/>

  </div>
  
  )
}

export default App
