import Topo from './components/Topo.jsx'
import Menu from './components/Menu.jsx'
import Coisa from './components/Coisa.jsx'
import './App.css'

function App() {


  return (
    <div className="App">
    <Topo/>
    <Menu/>
    <Coisa/>
  </div>
  )
}

export default App
