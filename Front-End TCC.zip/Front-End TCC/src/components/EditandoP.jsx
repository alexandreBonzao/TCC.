import { useState, useEffect } from "react";
import styles from "./EditandoP.module.css";
import Button from 'react-bootstrap/Button';
import { useNavigate } from "react-router-dom";
import api from "../services/api";

export default function EditandoP() {
    const navigate = useNavigate();
    const [dados, setDados] = useState({
        nome: "",
        cpf_cnpj: "",
        email: "",
        senha: ""
    });

    // Busca dados do cliente ao carregar
    useEffect(() => {
        const fetchDados = async () => {
            try {
                const token = localStorage.getItem("token");
                const response = await api.get("/auth/me", {
                    headers: { Authorization: `Bearer ${token}` }
                });

                const data = response.data;
                setDados({
                    nome: data.nome || "",
                    cpf_cnpj: data.cpf_cnpj || "",
                    email: data.email || "",
                    senha: "" // senha não é retornada pelo backend
                });
            } catch (error) {
                console.error("Erro ao buscar dados:", error);
                alert("Não foi possível carregar os dados do usuário.");
            }
        };

        fetchDados();
    }, []);

    // Atualiza estado ao digitar
    const handleChange = (e) => {
        setDados({ ...dados, [e.target.name]: e.target.value });
    };

    // Salva alterações
    const handleSave = async () => {
        try {
            const token = localStorage.getItem("token");
            await api.put("/auth/me/dados", dados, {
                headers: { Authorization: `Bearer ${token}` }
            });

            alert("Dados pessoais atualizados com sucesso!");
            navigate("/home");
        } catch (error) {
            console.error("Erro ao salvar dados:", error);
            alert("Falha ao atualizar dados pessoais.");
        }
    };

    return (
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.conteudo}>
                    <div className={styles.pessoais}>
                        <div className={styles.info}>
                            <div className={styles.titulo}>
                                <h1>Dados Pessoais</h1>
                            </div>

                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="nome"
                                    placeholder="Nome"
                                    value={dados.nome}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="cpf_cnpj"
                                    placeholder="CPF/CNPJ"
                                    value={dados.cpf_cnpj}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="email"
                                    name="email"
                                    placeholder="E-mail"
                                    value={dados.email}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="password"
                                    name="senha"
                                    placeholder="Senha"
                                    value={dados.senha}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>

                        <div className={styles.gambiarra}>
                            <Button className={styles.editar} onClick={handleSave}>
                                Salvar
                            </Button>
                        </div>
                    </div>

                    {/* Mantém seção de endereço com link para EditandoE */}
                    <div className={styles.endereco}>
                        <div className={styles.info}>
                            <div className={styles.titulo}><h1>Endereço</h1></div>
                            <h1>Logradouro:</h1>
                            <h1>Bairro:</h1>
                            <h1>Número:</h1>
                            <h1>Complemento:</h1>
                            <h1>Cidade:</h1>
                        </div>
                        <div className={styles.gambiarra}>
                            <Button
                                className={styles.editar}
                                onClick={() => navigate("/editarE")}
                            >
                                Editar
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
