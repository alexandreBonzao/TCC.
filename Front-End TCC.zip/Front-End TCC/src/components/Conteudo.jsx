import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./Conteudo.module.css";
import Button from "react-bootstrap/Button";
import api from "../services/api"; // seu arquivo de configuração Axios

export default function Conteudo() {
  const [cliente, setCliente] = useState(null);

  useEffect(() => {
    const fetchCliente = async () => {
      try {
        // Pega o token salvo no localStorage
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("Token não encontrado. Faça login.");
          return;
        }

        // Faz a requisição ao backend passando o token no header
        const response = await api.get("/auth/me", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        // Atualiza o estado com os dados retornados
        setCliente(response.data);
      } catch (error) {
        console.error("Erro ao buscar dados do cliente:", error.response || error);
      }
    };

    fetchCliente();
  }, []);

  if (!cliente) {
    return <div>Carregando...</div>;
  }

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        <div className={styles.conteudo}>
          <div className={styles.pessoais}>
            <div className={styles.info}>
              <div className={styles.titulo}>
                <h1>Dados Pessoais</h1>
              </div>
              <h1>Nome: {cliente.nome}</h1>
              <h1>CPF/CNPJ: {cliente.cpf_cnpj}</h1>
              <h1>E-mail: {cliente.email}</h1>
            </div>
            <div>
              <Link to="/editarp">
                <Button className={styles.editar}>Editar</Button>
              </Link>
            </div>
          </div>

          <div className={styles.endereco}>
            <div className={styles.info}>
              <div className={styles.titulo}>
                <h1>Endereço</h1>
              </div>
              <h1>Logradouro: {cliente.logradouro}</h1>
              <h1>Bairro: {cliente.bairro}</h1>
              <h1>Número: {cliente.numero}</h1>
              <h1>Complemento: {cliente.complemento}</h1>
              <h1>Cidade: {cliente.cidade}</h1>
            </div>
            <div>
              <Link to="/editare">
                <Button className={styles.editar}>Editar</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
