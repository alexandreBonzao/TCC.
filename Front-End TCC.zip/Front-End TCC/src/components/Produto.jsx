import { useEffect, useState } from "react";
import axios from "axios";
// import styles from "./produto.module.css"; // Descomente se tiver o arquivo CSS
import { Link, useSearchParams } from "react-router-dom"; // IMPORTANTE: useSearchParams

export default function Produto() {
  const [todosItens, setTodosItens] = useState([]); 
  const [filtroPreco, setFiltroPreco] = useState([]);
  
  // 1. HOOK PARA LER A URL
  const [searchParams] = useSearchParams();

  // 2. INICIALIZA O ESTADO JÁ COM O FILTRO DA URL (SE HOUVER)
  // O filtro 'Todos' é usado se não houver filtro na URL, mas se houver, usamos ele.
  const [filtroCategoria, setFiltroCategoria] = useState(() => {
    const categoriaUrl = searchParams.get("categoria");
    // Se houver uma categoria na URL (ex: ?categoria=Serviços), inicializa com ela.
    // Caso contrário, inicia vazio (mostra todos).
    return categoriaUrl ? [categoriaUrl] : [];
  });

  // URL da API
  const API_URL = "http://localhost:8080";

  useEffect(() => {
    const carregarDados = async () => {
      try {
        // Busca Produtos e Serviços simultaneamente
        const [resProdutos, resServicos] = await Promise.all([
          axios.get(`${API_URL}/produtos`),
          axios.get(`${API_URL}/servicos`)
        ]);

        // Adiciona uma propriedade 'origem' para distinguir os itens
        const produtosMarcados = resProdutos.data.map(p => ({ ...p, origem: 'produto' }));
        const servicosMarcados = resServicos.data.map(s => ({ ...s, origem: 'servico' }));

        setTodosItens([...produtosMarcados, ...servicosMarcados]);

      } catch (err) {
        console.error("Erro ao carregar dados:", err);
      }
    };
    carregarDados();
    // Este useEffect só roda no carregamento inicial da página
  }, []);

  // Lógica de Filtragem Avançada
  const itensFiltrados = todosItens.filter((item) => {
    const preco = item.preco || 0;
    
    // 1. Filtro de Preço
    const precoOk =
      filtroPreco.length === 0 ||
      filtroPreco.some((range) => {
        if (range === "100-500") return preco >= 100 && preco <= 500;
        if (range === "500-1000") return preco > 500 && preco <= 1000;
        if (range === "1000-5000") return preco > 1000 && preco <= 5000;
        return false;
      });

    // 2. Filtro de Categoria
    let categoriaItem = "";

    if (item.origem === 'servico') {
        categoriaItem = "Serviços"; 
    } else {
        // Usa o nome do tipo do produto (ex: 'Maquinário', 'Peça')
        // MUDANÇA: Remove 'Geral' como fallback para produtos sem categoria definida.
        categoriaItem = item.tipoProduto?.descricao || item.categoria || "";
    }
    
    const categoriaOk =
      filtroCategoria.length === 0 ||
      filtroCategoria.includes("Todos") || 
      filtroCategoria.includes(categoriaItem); 

    return precoOk && categoriaOk;
  });

  // Manipuladores de Checkbox
  const handlePrecoChange = (e, range) => {
    if (e.target.checked) {
      setFiltroPreco([...filtroPreco, range]);
    } else {
      setFiltroPreco(filtroPreco.filter((r) => r !== range));
    }
  };

  const handleCategoriaChange = (e, categoria) => {
    if (e.target.checked) {
      if (categoria === "Todos") {
          setFiltroCategoria(["Todos"]);
      } else {
          const novosFiltros = filtroCategoria.filter(c => c !== "Todos");
          setFiltroCategoria([...novosFiltros, categoria]);
      }
    } else {
      setFiltroCategoria(filtroCategoria.filter((c) => c !== categoria));
    }
  };

  // Funções auxiliares para determinar se o checkbox deve estar marcado
  const isCategoryChecked = (category) => {
      // Se não houver filtros, o "Todos" fica desmarcado (ou trate como desejar, mas aqui, se a lista for vazia, mostra todos os itens)
      if (filtroCategoria.length === 0 && category === "Todos") return false; 
      // Se a lista de filtros tiver 'Todos', apenas 'Todos' fica marcado
      if (filtroCategoria.includes("Todos")) return category === "Todos";
      // Verifica se a categoria está na lista de filtros
      return filtroCategoria.includes(category);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', backgroundColor: '#3d7e60', minHeight: '100vh', padding: '20px' }}>
      <div style={{ width: '90%', maxWidth: '1200px', backgroundColor: '#fff', borderRadius: '8px', padding: '20px', marginTop: '20px', display: 'flex', gap: '20px', flexDirection: 'row' }}>

        {/* ÁREA DE FILTROS */}
        <div style={{ width: '25%', minWidth: '200px', borderRight: '1px solid #ccc', paddingRight: '20px' }}>
          
          {/* Filtro de Preço */}
          <div style={{ marginBottom: '30px' }}>
            <h1 style={{ color: '#3d7e60', fontSize: '1.5em', marginBottom: '10px' }}>Preço</h1>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1em', margin: 0 }}>R$100 - R$500</h2>
                <input type="checkbox" onChange={(e) => handlePrecoChange(e, "100-500")} checked={filtroPreco.includes("100-500")}/>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1em', margin: 0 }}>R$500 - R$1000</h2>
                <input type="checkbox" onChange={(e) => handlePrecoChange(e, "500-1000")} checked={filtroPreco.includes("500-1000")}/>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1em', margin: 0 }}>R$1000 - R$5000</h2>
                <input type="checkbox" onChange={(e) => handlePrecoChange(e, "1000-5000")} checked={filtroPreco.includes("1000-5000")}/>
              </div>
            </div>
          </div>

          {/* Filtro de Categoria */}
          <div>
            <h1 style={{ color: '#3d7e60', fontSize: '1.5em', marginBottom: '10px' }}>Categorias</h1>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1em', margin: 0 }}>Todos</h2>
                <input 
                    type="checkbox" 
                    checked={isCategoryChecked("Todos")}
                    onChange={(e) => handleCategoriaChange(e, "Todos")}
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1em', margin: 0 }}>Maquinários</h2>
                <input 
                    type="checkbox" 
                    checked={isCategoryChecked("Maquinário")} // Note o singular
                    onChange={(e) => handleCategoriaChange(e, "Maquinário")}
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1em', margin: 0 }}>Peças</h2>
                <input 
                    type="checkbox" 
                    checked={isCategoryChecked("Peça")}
                    onChange={(e) => handleCategoriaChange(e, "Peça")}
                />
              </div>
              {/* REMOVIDO: Opção 'Geral' */}
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1em', margin: 0 }}>Serviços</h2>
                <input 
                    type="checkbox" 
                    checked={isCategoryChecked("Serviços")} // Note o plural
                    onChange={(e) => handleCategoriaChange(e, "Serviços")}
                />
              </div>
            </div>
          </div>
        </div>

        {/* LISTA MISTA DE PRODUTOS E SERVIÇOS */}
        <div style={{ flex: 1, display: 'flex', flexWrap: 'wrap', gap: '20px', alignContent: 'flex-start' }}>
          {itensFiltrados.length > 0 ? (
            itensFiltrados.map((item) => { 
              const precoFormatado = item.preco != null ? item.preco.toFixed(2) : "0.00";
              const isService = item.origem === 'servico';
              const endpointFoto = isService ? 'fotos-servico' : 'fotos-produto';
              const rotaVer = isService ? 'servicoVer' : 'produtoVer';

              const imagemSrc =
                item.fotos && item.fotos.length > 0
                  ? `${API_URL}/${endpointFoto}/file/${item.fotos[0].id}`
                  : "/sem-foto.png";

              const estoque = item.estoque != null ? item.estoque : "Indisponível";
              const localizacao = item.localizacao || "Não informado";
              const nomeItem = item.nome || (isService ? "Serviço" : "Produto");

              return (
                <Link 
                    to={`/${rotaVer}/${item.id}`} 
                    key={`${item.origem}-${item.id}`} 
                    style={{ textDecoration: 'none', color: 'inherit', width: '250px', border: '1px solid #ddd', borderRadius: '8px', overflow: 'hidden', boxShadow: '0 2px 5px rgba(0,0,0,0.1)', display: 'flex', flexDirection: 'column' }}
                >
                  <div style={{ width: '100%', height: '200px', backgroundColor: '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <img 
                      src={imagemSrc} 
                      alt={nomeItem} 
                      style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'cover' }}
                      onError={(e) => e.target.src = "/sem-foto.png"}
                    />
                  </div>

                  <div style={{ padding: '15px', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                    <div style={{ fontSize: '1.2em', fontWeight: 'bold', color: '#333' }}>
                      {nomeItem}
                    </div>
                    {isService && (
                        <span style={{ fontSize: '0.8em', backgroundColor: '#3d7e60', color: '#fff', padding: '2px 6px', borderRadius: '4px', width: 'fit-content' }}>
                            Serviço
                        </span>
                    )}
                    <div style={{ fontSize: '0.9em', color: '#666', height: '40px', overflow: 'hidden' }}>
                      {item.descricao || "Sem descrição"}
                    </div>
                    <div style={{ fontSize: '1.3em', fontWeight: 'bold', color: '#3d7e60', marginTop: '5px' }}>
                      R$ {precoFormatado}
                    </div>
                    <div style={{ fontSize: '0.8em', color: '#999' }}>
                      {localizacao}
                    </div>
                  </div>

                  <div style={{ padding: '10px', backgroundColor: '#f9f9f9', borderTop: '1px solid #eee', fontSize: '0.9em', textAlign: 'center' }}>
                    {isService ? 'Agende agora' : `Estoque: ${estoque}`}
                  </div>
                </Link>
              );
            })
          ) : (
            <div style={{ width: '100%', textAlign: 'center', marginTop: '50px' }}>
                <h2 style={{ color: "#666" }}>Nenhum item encontrado com estes filtros.</h2>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}