import { useState, useEffect } from "react";
import styles from "./EditandoP.module.css"; // Mantém o mesmo CSS para estilo igual
import Button from 'react-bootstrap/Button';
import { useNavigate } from "react-router-dom";
import api from "../services/api";

export default function EditandoE() {
    const navigate = useNavigate();

    // Estado unificado para dados pessoais + endereço
    const [dados, setDados] = useState({
        nome: "",
        cpf_cnpj: "",
        email: "",
        senha: "",
        logradouro: "",
        bairro: "",
        numero: "",
        complemento: "",
        cidade: ""
    });

    // Busca dados do usuário ao carregar
    useEffect(() => {
        const fetchDados = async () => {
            try {
                const token = localStorage.getItem("token");
                const response = await api.get("/auth/me", {
                    headers: { Authorization: `Bearer ${token}` }
                });

                const data = response.data;
                setDados({
                    nome: data.nome || "",
                    cpf_cnpj: data.cpf_cnpj || "",
                    email: data.email || "",
                    senha: "", // senha não vem do backend
                    logradouro: data.logradouro || "",
                    bairro: data.bairro || "",
                    numero: data.numero || "",
                    complemento: data.complemento || "",
                    cidade: data.cidade || ""
                });
            } catch (error) {
                console.error("Erro ao buscar dados:", error);
                alert("Não foi possível carregar os dados do usuário.");
            }
        };

        fetchDados();
    }, []);

    // Atualiza estado ao digitar em qualquer input
    const handleChange = (e) => {
        setDados({ ...dados, [e.target.name]: e.target.value });
    };

    // Salva alterações pessoais e de endereço
    const handleSave = async () => {
        try {
            const token = localStorage.getItem("token");

            // Atualiza dados pessoais
            await api.put("/auth/me/dados", {
                nome: dados.nome,
                cpf_cnpj: dados.cpf_cnpj,
                email: dados.email,
                senha: dados.senha,
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            // Atualiza endereço
            await api.put("/auth/me", {
                logradouro: dados.logradouro,
                bairro: dados.bairro,
                numero: dados.numero,
                complemento: dados.complemento,
                cidade: dados.cidade
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            alert("Dados atualizados com sucesso!");
            navigate("/home");
        } catch (error) {
            console.error("Erro ao salvar dados:", error);
            alert("Falha ao atualizar dados.");
        }
    };

    return (
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.conteudo}>

                    {/* Dados Pessoais */}
                    <div className={styles.pessoais}>
                        <div className={styles.info}>
                            <div className={styles.titulo}><h1>Dados Pessoais</h1></div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="nome"
                                    placeholder="Nome"
                                    value={dados.nome}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="cpf_cnpj"
                                    placeholder="CPF/CNPJ"
                                    value={dados.cpf_cnpj}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="email"
                                    name="email"
                                    placeholder="E-mail"
                                    value={dados.email}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="password"
                                    name="senha"
                                    placeholder="Senha"
                                    value={dados.senha}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Endereço */}
                    <div className={styles.endereco}>
                        <div className={styles.info}>
                            <div className={styles.titulo}><h1>Endereço</h1></div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="logradouro"
                                    placeholder="Logradouro"
                                    value={dados.logradouro}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="bairro"
                                    placeholder="Bairro"
                                    value={dados.bairro}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="numero"
                                    placeholder="Número"
                                    value={dados.numero}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="complemento"
                                    placeholder="Complemento"
                                    value={dados.complemento}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className={styles.barra}>
                                <input
                                    type="text"
                                    name="cidade"
                                    placeholder="Cidade"
                                    value={dados.cidade}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Botão Salvar */}
                    <div className={styles.gambiarra}>
                        <Button className={styles.editar} onClick={handleSave}>
                            Salvar
                        </Button>
                    </div>

                </div>
            </div>
        </div>
    );
}
