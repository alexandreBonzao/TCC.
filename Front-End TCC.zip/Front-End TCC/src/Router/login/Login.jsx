import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../../services/api'; // Axios configurado
import './Login.css';

export default function Login() {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await api.post('/auth/login', {
                email,
                password // envia exatamente como está na DTO
            });

            // salva token no localStorage
            localStorage.setItem('token', response.data.token);

            navigate('/home'); // redireciona para home
        } catch (error) {
            console.error(error);
            alert("Falha no login. Verifique suas credenciais.");
        }
    };

    return (
        <div className="cont">
            <div className="container">
                <form onSubmit={handleSubmit}>
                    <h1>Acesse o Sistema</h1>

                    <div className="input-field">
                        <input
                            type="email"
                            placeholder="E-mail"
                            required
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    <div className="input-field">
                        <input
                            type="password"
                            placeholder="Senha"
                            required
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>

                    <button type="submit">Entrar</button>

                    <div className="signup-link">
                        <p>Não tem uma conta?</p>
                        <Link to="/Cadastro">
                            <div className='cor'>Cadastrar</div>
                        </Link>
                    </div>
                </form>
            </div>
        </div>
    );
}
