import Topo from '../../components/Topo'
import Menu from '../../components/Menu'
import PecasVer from '../../components/PecasVer'

export default function ProdutoVer() {

    return (
      <div className="App">
        <div><Topo/></div>
        <div><Menu/></div>
        <div><PecasVer/></div>
      </div>
    );
  }