import { useState } from "react";
import axios from "axios";
import styles from "./ProdutosAdd.module.css";

export default function ProdutosAdd() {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [preco, setPreco] = useState("");
  const [estoque, setEstoque] = useState("");
  const [arquivoFotos, setArquivoFotos] = useState([]);
  const [previewFotos, setPreviewFotos] = useState([]);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setArquivoFotos(files);

    const previews = files.map((file) => URL.createObjectURL(file));
    setPreviewFotos(previews);
  };

  const handleAddProduto = async () => {
    try {
      const produtoRes = await axios.post("http://localhost:8080/produtos", {
        nome,
        descricao,
        preco: parseFloat(preco),
        estoque: parseInt(estoque),
      });

      const produtoCriado = produtoRes.data;

      if (arquivoFotos.length > 0) {
        const formData = new FormData();
        arquivoFotos.forEach((file) => formData.append("files", file));

        await axios.post(
          `http://localhost:8080/fotos-produto/${produtoCriado.id}/upload-multiple`,
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      }

      alert("Produto e fotos cadastrados com sucesso!");
      setNome("");
      setDescricao("");
      setPreco("");
      setEstoque("");
      setArquivoFotos([]);
      setPreviewFotos([]);
    } catch (err) {
      alert("Erro ao cadastrar produto. Veja o console.");
      console.error(err);
    }
  };

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>

        {/* ÁREA PRINCIPAL */}
        <div className={styles.produto}>
          
          {/* BOX DA IMAGEM */}
          <div className={styles.img}>
            {previewFotos.length > 0 ? (
              <img src={previewFotos[0]} alt="preview" />
            ) : (
              <span className="imgtext">Clique para enviar imagem</span>
            )}

            <input 
              type="file" 
              multiple 
              onChange={handleFileChange}
              style={{ display: "none" }}
              id="fileInput"
            />
          </div>

          {/* CONTEÚDO DO FORMULÁRIO */}
          <div className={styles.conteudo}>

            <div className={styles.titulo}>
              <input
                placeholder="Nome"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
              />
            </div>

            <div className={styles.desc}>
              <input
                placeholder="Descrição"
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
              />
            </div>
            
            <select
              defaultValue=""
              required
              className={styles.select}
            >
              <option value="" disabled hidden>
                Tipo
              </option>

            <option value="geral">Geral</option>
            <option value="maquinario">Maquinário</option>
            <option value="peca">Peça</option>
          </select> 
            

            <div className={styles.endereco}>
              <input
                placeholder="Estoque"
                type="number"
                value={estoque}
                onChange={(e) => setEstoque(e.target.value)}
              />
            </div>

            <div className={styles.preco}>
              <input
                placeholder="Preço"
                type="number"
                value={preco}
                onChange={(e) => setPreco(e.target.value)}
              />
            </div>
          </div>

          

        </div>

          <div className={styles.contato}><h1>Adicione um E-mail e um Telefone para contato</h1></div>
          <div className={styles.coisa}>
              <div className={styles.conte}>            
                  <input type="text" placeholder="E-mail" />                         
              </div>              
              <div className={styles.conte}>                
                  <input type="text" placeholder="Telefone" />              
              </div>              
            </div>               

        {/* BOTÃO ADICIONAR */}
        <div className={styles.areaBotao}>
          <button className={styles.botaoAdicionar} onClick={handleAddProduto}>
            Adicionar
          </button>
        </div>

      </div>
    </div>
  );
}