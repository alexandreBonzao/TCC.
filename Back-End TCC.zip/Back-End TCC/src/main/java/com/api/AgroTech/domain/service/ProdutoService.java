package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Produto;
import com.api.AgroTech.domain.repository.ProdutoRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;

    public ProdutoService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    // Listar todos os produtos
    public List<Produto> listarTodos() {
        return produtoRepository.findAll();
    }

    // Buscar produto por ID
    public Optional<Produto> buscarPorId(Long produtoId) {
        return produtoRepository.findById(produtoId);
    }

    // Salvar novo produto
    public Produto salvar(Produto produto) {
        return produtoRepository.save(produto);
    }

    // Atualizar produto existente
    public Optional<Produto> atualizar(Long produtoId, Produto produtoAtualizado) {
        return produtoRepository.findById(produtoId)
                .map(produtoExistente -> {
                    produtoExistente.setNome(produtoAtualizado.getNome());
                    produtoExistente.setDescricao(produtoAtualizado.getDescricao());
                    produtoExistente.setPreco(produtoAtualizado.getPreco());
                    produtoExistente.setEstoque(produtoAtualizado.getEstoque());
                    produtoExistente.setLocalizacao(produtoAtualizado.getLocalizacao());
                    produtoExistente.setEmailContato(produtoAtualizado.getEmailContato());
                    produtoExistente.setTelefoneContato(produtoAtualizado.getTelefoneContato());
                    produtoExistente.setTipoProduto(produtoAtualizado.getTipoProduto());
                    produtoExistente.setCliente(produtoAtualizado.getCliente());
                    return produtoRepository.save(produtoExistente);
                });
    }

    // Excluir produto
    public void excluir(Long produtoId) throws EntidadeNaoEncontradaException, EntidadeEmUsoException {
        try {
            if (!produtoRepository.existsById(produtoId)) {
                throw new EntidadeNaoEncontradaException(
                        String.format("Produto de id %d não encontrado", produtoId));
            }
            produtoRepository.deleteById(produtoId);
        } catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(
                    String.format("Produto de id %d não pode ser removido, pois está em uso", produtoId));
        }
    }
}
