package com.api.AgroTech.domain.repository;

import com.api.AgroTech.domain.model.Estado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EstadoRepository extends JpaRepository<Estado, Long> {
    Optional<Estado> findByNome(String nome);
    Optional<Estado> findBySigla(String sigla);
}
