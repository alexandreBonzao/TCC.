package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.TipoProduto;
import com.api.AgroTech.domain.repository.TipoProdutoRepository;
import com.api.AgroTech.domain.service.TipoProdutoService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tiposProduto")
@CrossOrigin(origins = "*") // 🌐 CORREÇÃO 1: Permite o acesso do Front-end (CORS)
public class TipoProdutoController {

    @Autowired
    private TipoProdutoRepository tipoProdutoRepository;

    @Autowired
    private TipoProdutoService tipoProdutoService;

    // ⚙️ CORREÇÃO 3: Retorna ResponseEntity para consistência REST
    @GetMapping
    public ResponseEntity<List<TipoProduto>> listar() {
        List<TipoProduto> tiposProduto = tipoProdutoRepository.findAll();
        return ResponseEntity.ok(tiposProduto);
    }

    // ⚙️ CORREÇÃO 2: Path Variable consistente com o nome da variável no método
    @GetMapping("/{tipoProdutoId}")
    public ResponseEntity<TipoProduto> buscar(@PathVariable Long tipoProdutoId) {
        Optional<TipoProduto> tipoProduto = tipoProdutoRepository.findById(tipoProdutoId);

        if (tipoProduto.isPresent()) {
            return ResponseEntity.ok(tipoProduto.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<TipoProduto> adicionar(@RequestBody TipoProduto tipoProduto) {
        tipoProduto = tipoProdutoService.salvar(tipoProduto);
        return ResponseEntity.status(HttpStatus.CREATED).body(tipoProduto);
    }

    // ⚙️ CORREÇÃO 2: Path Variable consistente com o nome da variável no método
    @PutMapping("/{tipoProdutoId}")
    public ResponseEntity<TipoProduto> atualizar (@PathVariable Long tipoProdutoId, @RequestBody TipoProduto tipoProduto) {
        Optional<TipoProduto> tipoProdutoAtual = tipoProdutoRepository.findById(tipoProdutoId);

        if (tipoProdutoAtual.isPresent()) {
            // O nome do campo do método 'get()' do Optional precisa ser usado no BeanUtils
            BeanUtils.copyProperties(tipoProduto, tipoProdutoAtual.get(), "id");

            TipoProduto tipoProdutoSalvo = tipoProdutoService.salvar(tipoProdutoAtual.get());
            return ResponseEntity.ok(tipoProdutoSalvo);
        }
        return ResponseEntity.notFound().build();
    }

    // ⚙️ CORREÇÃO 2: Path Variable consistente com o nome da variável no método
    @DeleteMapping("/{tipoProdutoId}")
    public ResponseEntity<Void> remover(@PathVariable Long tipoProdutoId) { // Mudança para ResponseEntity<Void> no delete
        try {
            tipoProdutoService.excluir(tipoProdutoId);
            return ResponseEntity.noContent().build(); // Resposta 204 No Content
        }
        catch (EntidadeNaoEncontradaException e) {
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}