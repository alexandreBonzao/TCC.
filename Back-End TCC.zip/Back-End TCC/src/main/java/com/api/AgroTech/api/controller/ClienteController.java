package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Cliente;
import com.api.AgroTech.domain.repository.ClienteRepository;
import com.api.AgroTech.domain.service.ClienteService;
import org.apache.coyote.Response;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/clientes")
public class ClienteController {
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private ClienteService clienteService;

    @GetMapping
    public List<Cliente> listar() { return clienteRepository.findAll(); }

    @GetMapping("/{clienteId}")
    public ResponseEntity<Cliente> buscar(@PathVariable Long clienteId) {
        Optional<Cliente> cliente = clienteRepository.findById(clienteId);

        if (cliente.isPresent()) {
            return ResponseEntity.ok(cliente.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Cliente> adicionar(@RequestBody Cliente cliente) {
        cliente = clienteService.salvar(cliente);
        return ResponseEntity.status(HttpStatus.CREATED).body(cliente);
    }

    @PutMapping("/{clienteId}")
    public ResponseEntity<Cliente> atualizar (@PathVariable Long clienteId, @RequestBody Cliente cliente) {
        Optional<Cliente> clienteAtual = clienteRepository.findById(clienteId);

        if (clienteAtual.isPresent()) {
            BeanUtils.copyProperties(cliente, clienteAtual, "id");

            Cliente clienteSalvo = clienteService.salvar(clienteAtual.get());
            return ResponseEntity.ok(clienteSalvo);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{clienteId}")
    public ResponseEntity<Cliente> remover (@PathVariable Long clienteId) {
        try {
            clienteService.excluir(clienteId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e) {
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
