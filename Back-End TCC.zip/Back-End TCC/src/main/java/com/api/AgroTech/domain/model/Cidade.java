package com.api.AgroTech.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)

public class Cidade {
    @Id
    @EqualsAndHashCode.Include
    private Long id; // id = código IBGE


    private String nome;

    @ManyToOne
    @JoinColumn(name = "estado_id")
    private Estado estado;
}