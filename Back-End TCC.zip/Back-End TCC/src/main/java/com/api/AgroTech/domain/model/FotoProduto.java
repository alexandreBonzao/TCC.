package com.api.AgroTech.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnore; // Importe essa anotação!
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "foto_produto")
public class FotoProduto {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nomeArquivo;

    private String tipoConteudo;

    @JsonIgnore // 🛑 CORREÇÃO 1: Evita que os bytes (dados da imagem) sejam enviados na lista de produtos.
    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] conteudo;

    private LocalDateTime dataUpload;

    @JsonIgnore // 🛑 CORREÇÃO 2: Evita o loop infinito de serialização (Produto -> Foto -> Produto...).
    @ManyToOne
    @JoinColumn(name = "produto_id")
    private Produto produto;
}