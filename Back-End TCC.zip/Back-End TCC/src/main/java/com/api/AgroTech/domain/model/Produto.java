package com.api.AgroTech.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.List;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "produto")
public class Produto {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nome_produto")
    private String nome;

    @Column(columnDefinition = "TEXT")
    private String descricao;

    private String localizacao;

    private Double preco;

    @Column(name = "email_contato")
    private String emailContato;

    @Column(name = "telefone_contato")
    private String telefoneContato;

    @Column(name = "estoque")
    private Integer estoque;

    // Sempre carregar TipoProduto junto
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "tipo_produto_id")
    private TipoProduto tipoProduto;

    // Sempre carregar Cliente junto
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @OneToMany(mappedBy = "produto", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<FotoProduto> fotos;
}
