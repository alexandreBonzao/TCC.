package com.api.AgroTech.domain.repository;

import com.api.AgroTech.domain.model.FotoServico;
import com.api.AgroTech.domain.model.Servico;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FotoServicoRepository extends JpaRepository<FotoServico, Long> {
    Optional<FotoServico> findByNomeArquivo(String nomeArquivo);

    List<FotoServico> findByServico(Servico servico);
}
