package com.api.AgroTech.domain.repository;

import com.api.AgroTech.domain.model.Servico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServicoRepository extends JpaRepository<Servico, Long> {}
