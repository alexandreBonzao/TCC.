import styles from "./EditandoE.module.css";
import Button from 'react-bootstrap/Button';

export default function EditandoE() {

    return (
      <div className={styles.tudo}>
          <div className={styles.container}>
              <div className={styles.conteudo}>
                <div className={styles.pessoais}>
                    <div className={styles.info}>
                        <div className={styles.titulo}><h1>Dados Pessoais</h1></div>
                        <h1>Nome:</h1>
                        <h1>CPF/CNPJ:</h1>
                        <h1>E-mail:</h1>
                        <h1>Senha:</h1>
                    </div>
                    <div><Button className={styles.editar}>Salvar</Button></div>
                </div>
                
                  
                <div className={styles.endereco}>
                    <div className={styles.info}>
                        <div className={styles.titulo}><h1>Endereço</h1></div>
                        <div className={styles.barra}><h1>Logradouro:</h1><input type="text" placeholder="Logradouro" /></div>
                        <div className={styles.barra}><h1>Bairro:</h1><input type="text" placeholder="Logradouro" /></div>
                        <div className={styles.barra}><h1>Numero:</h1><input type="text" placeholder="Logradouro" /></div>
                        <div className={styles.barra}><h1>Complemento:</h1><input type="text" placeholder="Logradouro" /></div>
                        <div className={styles.barra}><h1>Cidade:</h1><input type="text" placeholder="Logradouro" /></div>
                    </div><div><Button className={styles.editar}>Editar</Button></div>
                </div> 
                
              </div>
          </div>
      </div>
    );
  }