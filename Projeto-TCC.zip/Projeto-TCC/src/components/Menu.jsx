import styles from "./Menu.module.css";
import { useState } from "react";
import { Link } from "react-router-dom"; 

export default function Menu() {
  const [open, setOpen] = useState(false);

  const toggleDropdown = () => {
    setOpen(!open);
  };

  return (
    <div className={styles.container}>
      <div className={styles.conteudo}>
        <div className={styles.c1} onClick={toggleDropdown}>
          Categorias
          {open && (
            <div className={styles.drop}>
              <Link to="/produtos"><div>Produtos</div></Link>
              <Link to="/produtos"><div>Serviços</div></Link>
              <Link to="/produtos"><div>Maquinários</div></Link>
              <Link to="/produtos"><div>Peças</div></Link>
            </div>
          )}
        </div>
        <Link to="/contato" className={styles.c2}><div>Contato</div></Link>
        <Link to="/produtoAdd" className={styles.c3}><div>Vender</div></Link>
        <Link to="/conta" className={styles.c4}><div>Conta</div></Link>
      </div>
    </div>
  );
}