import { useState } from "react";
import styles from "./Menu.module.css";

export default function Menu() {
  const [open, setOpen] = useState(false);

  const toggleDropdown = () => {
    setOpen(!open);
  };

  return (
    <div className={styles.container}>
      <div className={styles.conteudo}>
        <div className={styles.c1} onClick={toggleDropdown}>
          Produtos
          {open && (
            <div className={styles.drop}>
              <a href="#"><div>Serviços</div></a>
              <a href="#"><div>Maquinários</div></a>
              <a href="#"><div>Peças</div></a>
            </div>
          )}
        </div>
        <div className={styles.c3}>Vender</div>
        <div className={styles.c4}>Contato</div>
        <div className={styles.c5}>Conta</div>
      </div>
    </div>
  );
}