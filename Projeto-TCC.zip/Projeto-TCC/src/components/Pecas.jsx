import styles from "./produto.module.css";
import disco from "../assets/disco.png";
import correa from "../assets/correa.png";
import arado from "../assets/arado.png";
import filtro from "../assets/filtro.png";
import radiador from "../assets/radiador.png";
import { Link } from "react-router-dom";

export default function Produto(){
    return(
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.filtro}>
                    <div className={styles.fpreco}>
                        <h1>Preço</h1>

                        <div className={styles.marcar}>
                            <div className={styles.primeiro}>
                                <h2>R$100,00 até R$500,00</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.segundo}>
                                <h2>R$500,00 até R$1000,00</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.terceiro}>
                                <h2>R$1000,00 até R$5000,00</h2>
                                <input type="checkbox"/>
                            </div>

                            <div className={styles.menor}>
                                <h1>Menor Preço</h1>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.maior}>
                                <h1>Maior Preço</h1>
                                <input type="checkbox"/>
                            </div>
                        </div>
                    </div>

                    <div className={styles.fcategoria}>
                        <h1>Categorias</h1>

                        <div className={styles.marcar}>
                            <div className={styles.cprimeiro}>
                                <h2>Todos os Produtos</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.csegundo}>
                                <h2>Maquinários</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.cterceiro}>
                                <h2>Peças</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.cquarto}>
                                <h2>Serviços</h2>
                                <input type="checkbox"/>
                            </div>
                        </div>
                    </div>
                </div>

                <div className={styles.gprod}>
                    
                    <Link to="/pecasVer" className={styles.produtos}>
                        <div className={styles.img}><img src={disco} alt="Disco de Grade Aradora"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Disco de Grade Aradora</h1></div>
                        <div className={styles.desc}><h1>Disco Para Grade Aradora Ou Intermediária 24 Polegadas</h1></div>
                        <div className={styles.preco}><h1>R$ 650,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/pecasVer" className={styles.produtos}>
                        <div className={styles.img}><img src={correa} alt="Correia de Transmissão"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Correia de Transmissão para Colheitadeira</h1></div>
                        <div className={styles.desc}><h1>Correia de Transmissão em V Dentada 5vx-630 Menco</h1></div>
                        <div className={styles.preco}><h1>R$ 50,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/pecasVer" className={styles.produtos}>
                        <div className={styles.img}><img src={arado} alt="Lâmina de Arado"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Arado Subsolador</h1></div>
                        <div className={styles.desc}><h1>Arado Subsolador 1700 - 5h - C/ Abrac</h1></div>
                        <div className={styles.preco}><h1>R$ 8.000,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/pecasVer" className={styles.produtos}>
                        <div className={styles.img}><img src={filtro} alt="Filtro de Ar para Trator"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Filtro de Ar para Trator</h1></div>
                        <div className={styles.desc}><h1>Filtros De Ar Trator Massey 4275 Perkins 4cil 2010/em Diante</h1></div>
                        <div className={styles.preco}><h1>R$ 150,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/pecasVer" className={styles.produtos}>
                        <div className={styles.img}><img src={radiador} alt="Radiador agrícola"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Radiador De Água</h1></div>
                        <div className={styles.desc}><h1>Radiador De Água Valtra Valmet Trator Bh180 635x615x5ob</h1></div>
                        <div className={styles.preco}><h1>R$ 5.000,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>

                </div>

            </div>
        </div>
    );
}