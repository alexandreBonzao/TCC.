import styles from './ProdutosVer.module.css'
import makita from "../assets/makita.png";

export default function ProdutosVer(){
    return(
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.produto}>
                    <img src={makita}/>
                    <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Makita</h1></div>
                        <div className={styles.desc}><h1>Serra Mármore 1200W 110mm M0400B-127V</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        <div className={styles.preco}><h1>R$100,00</h1></div>
                    </div>
                </div>

                <div className={styles.contato}><h1>Se houver interesse entre em contato com o vendedor</h1></div>
                <div className={styles.coisa}>
                    <div className={styles.conte}>
                        <h2>E-mail:</h2>
                        <h1>vendedormakita@gmail.com</h1>
                    </div>
                    <div className={styles.conte}>
                        <h2>Telefone:</h2>
                        <h1>13 9914-1954</h1>
                    </div>
                </div>

            </div>
        </div>
    );
}