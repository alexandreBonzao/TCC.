import styles from './ProdutosVer.module.css;'

export default function ProdutosVer(){
    return(
        <div></div>
    );
}