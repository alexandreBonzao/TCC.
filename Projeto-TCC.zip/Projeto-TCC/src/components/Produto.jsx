import styles from "./produto.module.css";
import makita from "../assets/makita.png";

export default function Produto(){
    return(
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.filtro}></div>

                <div className={styles.produtos}>
                    <div className={styles.img}><img src={makita}/></div>
                    <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Makita</h1></div>
                        <div className={styles.desc}><h1>Serra Mármore 1200W 110mm M0400B-127V</h1></div>
                        <div className={styles.preco}><h1>R$100,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                    </div>
                    <div className={styles.aval}><h1>⭐⭐⭐⭐⭐</h1></div>
                </div>

            </div>
        </div>
    );
}