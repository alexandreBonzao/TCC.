import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import estilo from './Cadastro.module.css';

export default function Cadastro() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    documentation: "",
    logradouro: "",
    bairro: "",
    numero: "",
    complemento: "",
    cidade: ""
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      await api.post('/auth/register', {
        name: form.username,
        email: form.email,
        password: form.password,
        document: form.documentation,
        address: {
          street: form.logradouro,
          neighborhood: form.bairro,
          number: form.numero,
          complement: form.complemento,
          
        }
      });

      alert("Cadastro realizado com sucesso!");
      navigate('/login');

    } catch (error) {
      console.error("Erro no cadastro:", error);
      alert(error.response?.data?.message || "Falha no cadastro.");
    }
  };

  return (
    <div className={estilo.cont}>
      <div className={estilo.container}>
        <form onSubmit={handleSubmit}>
          <h1>Crie sua Conta para Entrar no Sistema</h1>

          <div className={estilo.inputfield}>
            <input type="email" name="email" placeholder="E-mail" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="password" name="password" placeholder="Senha" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="documentation" placeholder="CPF/CNPJ" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="username" placeholder="Usuário" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="logradouro" placeholder="Logradouro" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="bairro" placeholder="Bairro" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="numero" placeholder="Número" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="complemento" placeholder="Complemento" onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="cidade" placeholder="Cidade" required onChange={handleChange} />
          </div>

          <button type="submit">Cadastrar</button>
        </form>
      </div>
    </div>
  );
}